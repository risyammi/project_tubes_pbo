/* Nama Kelompok                  :
 * Kezia Tabhita Smith              140810240020
 * Risyam Muhammad Iesqillah		140810240032
 * Laudzan Ananda Syawaliandi		140810240050
 * Dikumpulkan tanggal            : 7 Desember 2025
*/
package models;
import java.util.Objects;

public class Minuman extends Produk {
    public Minuman() {
        this.kategori = "MINUMAN";
    }
}